class FLO
{
	class Util
	{
		file = "Util";
		class ambientMortar {};
		class checkActiveCondition {};
		class getRandomTarget {};
	};
};