1. Place "Util" folder in the root of you mission.

2. Place the description.ext in the root of your mission, or merge its contents with yours if it already exists.

3. Read the comment at the top of "Util\fn_ambientMortar.sqf" for usage and examples.