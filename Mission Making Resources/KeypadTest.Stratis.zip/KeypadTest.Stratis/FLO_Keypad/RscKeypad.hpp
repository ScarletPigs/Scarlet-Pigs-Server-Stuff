class RscKeypad
{
	idd = 1988;
	onUnload = "params ['_control', '_exitCode']; private _obj = _control getVariable 'FLO_Keypad_Object'; _obj setVariable['FLO_Keypad_isOpen', false, true]; _obj setVariable['FLO_Keypad_enteredPassword', '', true];";
	
	class ControlsBackground
	{
		class Background: RscPicture
		{
			text  = "FLO_Keypad\Textures\keypad.paa";
			type = ST_PICTURE;
			idc = -1;
			x = GUI_GRID_CENTER_X + (12 * GUI_GRID_CENTER_W);
			y = GUI_GRID_CENTER_Y - (2 * GUI_GRID_CENTER_H);
			w = 14 * GUI_GRID_CENTER_W;
			h = 28 * GUI_GRID_CENTER_H;
		};
	};

	
	class Controls
	{
		class statusHeader: RscStructuredText
		{
			idc = 1989;
			text = "test";
			x = GUI_GRID_CENTER_X + (13.6 * GUI_GRID_CENTER_W);
			y = GUI_GRID_CENTER_Y + (2.2 * GUI_GRID_CENTER_H);
			w = GUI_GRID_CENTER_W * 10.9;
			h = GUI_GRID_CENTER_H * 1.2;
			colorBackground[] = {-1,-1,-1,0};
			class Attributes
			{
				font = "LucidaConsoleB";
				color = "#ccffcc";
				align = "center";
				valign = "middle";
				shadow = 1;
				shadowColor = "#003300";
				size = "1.1";
			};
		};
		
		class txtPassword: RscStructuredText
		{
			idc = 1990;
			text = "CODE: ";
			x = GUI_GRID_CENTER_X + (13.6 * GUI_GRID_CENTER_W);
			y = GUI_GRID_CENTER_Y + (3.5 * GUI_GRID_CENTER_H);
			w = GUI_GRID_CENTER_W * 10.9;
			h = GUI_GRID_CENTER_H * 1.2;
			colorBackground[] = {-1,-1,-1,0};
			class Attributes
			{
				font = "LucidaConsoleB";
				color = "#ccffcc";
				align = "left";
				valign = "middle";
				shadow = 1;
				shadowColor = "#003300";
				size = "1.1";
			};
		};
		
		class txtNrOfTries: RscStructuredText
		{
			idc = 1991;
			text = "3 tries left";
			x = GUI_GRID_CENTER_X + (13.6 * GUI_GRID_CENTER_W);
			y = GUI_GRID_CENTER_Y + (4.7 * GUI_GRID_CENTER_H);
			w = GUI_GRID_CENTER_W * 10.9;
			h = GUI_GRID_CENTER_H * 1.2;
			colorBackground[] = {-1,-1,-1,0};
			class Attributes
			{
				font = "LucidaConsoleB";
				color = "#ff3300";
				align = "right";
				valign = "middle";
				shadow = 1;
				shadowColor = "#003300";
				size = "0.8";
			};
		};
			
		class numButton1: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '1'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 13.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 15.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0  };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton2: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '2'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 16.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 15.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0  };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton3: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '3'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 19.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 15.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0  };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton4: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '4'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 13.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 12.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 1, 0, 1 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton5: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '5'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 16.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 12.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0  };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton6: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '6'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 19.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 12.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 1, 0, 1 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton7: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '7'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 13.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 9.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton8: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '8'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 16.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 9.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton9: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '9'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 19.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 9.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class numButton0: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, '0'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 13.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 18.85;
			w = GUI_GRID_CENTER_W * 4.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class delButton: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, 'del'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 19.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 18.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class enterButton: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "Params ['_ctrlButton'];private _obj = ctrlParent _ctrlButton getVariable 'FLO_Keypad_Object'; [_obj, 'enter'] spawn FLO_fnc_onKeyPress;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 22.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 15.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 5.2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
		class exitButton: RscButton
		{
			idc = -1;
			text = "";
			onButtonClick = "private _display = findDisplay 1988; _display closeDisplay 2;";
			x = GUI_GRID_CENTER_X + GUI_GRID_CENTER_W * 13.6;
			y = GUI_GRID_CENTER_Y + GUI_GRID_CENTER_H * 6.85;
			w = GUI_GRID_CENTER_W * 1.9;
			h = GUI_GRID_CENTER_H * 2;
			colorText[] = {0, 0, 0, 0 };
			colorDisabled[] = {0, 0, 0, 0 };
			colorBackground[] = {0, 0, 0, 0 };
			colorBackgroundDisabled[] = {0, 0, 0, 0 };
			colorBackgroundActive[] = {0, 0, 0, 0 };
			colorFocused[] = {0, 0, 0, 0 };
			colorShadow[] = {0, 0, 0, 0 };
			colorBorder[] = {0, 0, 0, 0 };
			soundClick[] = 
			{
				"\A3\ui_f\data\sound\RscButton\soundClick",
				0.09,
				1
			};
		};
	};
};