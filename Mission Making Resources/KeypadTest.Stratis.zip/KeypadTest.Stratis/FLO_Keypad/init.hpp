#include "\a3\ui_f\hpp\defineCommonGrids.inc"
#include "BaseControls.hpp"
#include "RscKeypad.hpp"

class CfgFunctions
{
	class FLO
	{
		class Keypad
		{
			file = "FLO_Keypad\Functions";
			class initKeypad {};
			class onKeyPress {};
			class onOpen {};
		};
	};
};